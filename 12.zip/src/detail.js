function execute(url) { 
            return Response.success({
                name: "Truyện EPUB", cover: "", description: "Tải tại mục danh sách", detail: "...", host: ""
            }); 
        }
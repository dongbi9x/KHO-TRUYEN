function execute(url) {
    return Response.success({
        name: "Truyện EPUB",
        author: "dongbi9x",
        description: "Tải file EPUB sạch đã lọc chữ ẩn.",
        detail: "Tác giả: dongbi9x",
        host: "https://github.com/dongbi9x"
    });
}
function execute(url) {
    // Trả về link để vBook tự xử lý hoặc hiển thị thông báo
    return Response.success("Link tải: " + url);
}
function execute(url) {
    return Response.success({
        name: "Truyện EPUB",
        cover: "https://via.placeholder.com/150",
        author: "Dongbi9x",
        description: "Truyện sạch đã lọc quảng cáo.",
        detail: "Kho truyện cá nhân",
        host: "https://raw.githubusercontent.com"
    });
}
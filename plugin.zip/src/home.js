function execute() {
    return Response.success([
        {title: "Cập nhật mới", input: "https://raw.githubusercontent.com/dongbi9x/KHO-TRUYEN/main/list.json", script: "gen.js"}
    ]);
}
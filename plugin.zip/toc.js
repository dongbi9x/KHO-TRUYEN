function execute(url) {
    return Response.success([
        {
            name: "NHẤN ĐỂ TẢI BẢN EPUB FULL",
            url: url,
            host: ""
        }
    ]);
}
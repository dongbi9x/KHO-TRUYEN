function execute(url) {
    return Response.success([{
        name: "Tải EPUB Ngay",
        url: url,
        host: "https://github.com"
    }]);
}
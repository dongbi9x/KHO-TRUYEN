function execute(url, page) {
            var response = fetch(url);
            if (response.ok) {
                var json = JSON.parse(response.string());
                var data = json.map(item => ({
                    name: item.title, link: item.url, cover: "https://via.placeholder.com/150", description: "EPUB", host: "https://github.com"
                }));
                return Response.success(data, null);
            }
            return Response.success([]); 
        }
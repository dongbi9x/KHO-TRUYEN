function execute() {
    return Response.success([
        {title: "Danh Sách Truyện", input: "https://raw.githubusercontent.com/dongbi9x/KHO-TRUYEN/main/list.json", script: "gen.js"}
    ]);
}